export class UserDTO{

    readonly name: string;

    readonly username: string;

    readonly password: string;

    readonly email: string;
}