import mongoose from "mongoose";

export class UserSchema extends mongoose.Schema {
    // constructor(options) {
    //     super(options);
    //     this.options = options;
    //     this.set('toJSON', {
    //         transform: (doc, ret) => {
    //             delete ret.password;
    //             delete ret.__v;
    //             ret.id = ret._id;
    //             delete ret._id;
    //         },
    //     });
    // }
}